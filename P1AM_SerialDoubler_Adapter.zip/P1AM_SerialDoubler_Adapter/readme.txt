The male "splayed" pins can be found here: 

Digikey Part# 952-3263-ND
Manufacterer Part# M20-8771042

The female pins are just the typical 2.54mm pitch female pin headers with the pins manually "splayed" as they don't sell female headers like that. 